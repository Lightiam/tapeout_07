%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-07-13T19:42:35-07:00*%
%TF.ProjectId,LR_P3A_DualNCE,4c525f50-3341-45f4-9475-616c4e43452e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Copper,L5,Inr*%
%TF.FilePolarity,Positive*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-07-13 19:42:35*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
