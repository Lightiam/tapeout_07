# Tapeout July_04 Schematic Transmittal

Date: 2026-07-05

Status: ENGINEERING ECO REQUIRED / RELEASE PENDING.

This package provides the current schematic set requested by the manufacturer so they can compare schematic intent against the PCB and identify open or missing items.

## Included files

- Clear dual-NCE/TFLN overview PDF: `01_pdf_and_svg/TFLN_AI_NODE_X2_CLEAR_DUAL_NCE_TFLN_SCHEMATIC_OVERVIEW.pdf`
- Native KiCad schematic: `00_native_kicad_schematic/TFLN_AI_NODE_X2_SERVER_CHASSIS_IO.kicad_sch`
- Native KiCad project: `00_native_kicad_schematic/TFLN_AI_NODE_X2_SERVER_CHASSIS_IO.kicad_pro`
- Clear schematic PDF: `01_pdf_and_svg/TFLN_AI_NODE_X2_SERVER_CHASSIS_IO_schematic.pdf`
- Zoomable schematic SVG: `01_pdf_and_svg/TFLN_AI_NODE_X2_SERVER_CHASSIS_IO.svg`
- KiCad XML netlist: `02_netlists/TFLN_AI_NODE_X2_SERVER_CHASSIS_IO_netlist_kicadxml.xml`
- KiCad S-expression netlist: `02_netlists/TFLN_AI_NODE_X2_SERVER_CHASSIS_IO_netlist_kicadsexpr.net`
- Schematic-derived BOM CSV: `03_bom_reference/TFLN_AI_NODE_X2_SERVER_CHASSIS_IO_schematic_bom.csv`
- Current release-pending BOM workbook: `03_bom_reference/Tapeout_July_04_CURRENT_BOM_RELEASE_PENDING.xlsx`
- Parity issue summary and detail CSV: `04_validation_context/`

## Current open validation items

KiCad schematic parity currently reports 564 issues:

- 199 net conflicts.
- 199 extra footprints.
- 84 footprint-symbol mismatches.
- 82 footprint/symbol field mismatches, including missing MPN fields.

Use `04_validation_context/SCHEMATIC_PARITY_ISSUES_DETAIL.csv` for the item-by-item engineering review.

## Engineering use

Use the schematic PDF for quick review and the native KiCad files/netlists for technical reconciliation. Final production release should follow after DRC closure, schematic parity closure, mechanical fit confirmation, and signed final BOM issue.

## Dual NCE and TFLN visibility note

The full KiCad schematic PDF is one dense A0 page, so the critical parts can be hard to see at normal zoom. The clear overview PDF explicitly calls out:

- `U1` NCE-A die.
- `U4` NCE-B die.
- `U3` TFLN photonic IC.
- `U50-U53` RF driver chain.
- `U30-U35` and `U40-U45` HBM4 groups.
