# Schematic Parity Summary

This summary is provided so engineering and manufacturing review can compare the supplied schematic against the PCB and identify open/missing items.

## Counts

- net_conflict: 199
- extra_footprint: 199
- footprint_symbol_mismatch: 84
- footprint_symbol_field_mismatch: 82

## Interpretation

- `extra_footprint`: PCB footprint currently has no corresponding schematic symbol mapping.
- `net_conflict`: PCB net assignment differs from the schematic connectivity.
- `footprint_symbol_mismatch`: schematic footprint field and PCB footprint assignment differ.
- `footprint_symbol_field_mismatch`: symbol/footprint fields differ, including missing MPN fields.

## Review instruction

Use the native KiCad schematic and PDF in this package as the reference schematic. Close each parity item by updating the schematic, updating the PCB, removing an intentional placeholder, or recording a signed engineering disposition.
