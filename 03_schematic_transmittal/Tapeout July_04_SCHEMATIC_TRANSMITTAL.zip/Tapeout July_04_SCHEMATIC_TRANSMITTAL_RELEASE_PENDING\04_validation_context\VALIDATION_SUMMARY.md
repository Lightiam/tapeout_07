# Validation Summary

## Rebuilt reference-envelope candidate

File: `00_OPEN_IN_KICAD/TFLN_AI_NODE_X2_SERVER_CHASSIS_IO.kicad_pcb`

- Candidate outline: 295.0 mm x 140.0 mm.
- Coordinate window: X=7.0..302.0 mm, Y=17.0..157.0 mm.
- KiCad CLI: 10.0.3.
- DRC: FAIL.
- DRC violations: 32.
- Unconnected items: 0.
- Schematic parity issues: 564.

## Reference source

The clean June source board was also checked with KiCad 10 and passed DRC at its original 305.0 mm x 267.0 mm outline:

- DRC: PASS.
- Violations: 0.
- Unconnected items: 0.

## Decision

This rebuild confirms that the requested reference-sized mechanical envelope can be represented in KiCad. The current design remains release-pending until DRC and schematic parity are closed.
