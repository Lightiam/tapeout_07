# Current Gaps To Do-Over Flow Map

| Open Item | Flow Step | What Engineers Fix | Acceptance Criteria |
| --- | --- | --- | --- |
| KiCad DRC fails with 32 violations | 6 / 7 | Move/trim no-net copper at edges, relocate ULREG/URREG, move CL32/CR32/DL32/DR32/JL32/JR32 inward, resolve MH5 edge clearance, and clean UPWR_L/UPWR_R silkscreen. | KiCad DRC returns 0 violations using the agreed board rules. |
| Schematic parity fails with 564 items | 2 / 7 | Reconcile PCB-to-schematic updates, classify extra footprints, resolve net conflicts, and fix footprint-symbol mismatches. | Parity is closed, or remaining items have signed engineering waivers. |
| 82 missing/mismatched MPN or field items | 5 | Update schematic and footprint fields, then regenerate grouped and expanded BOM from the closed design. | Signed final BOM with MPN, value, package, quantity, DNP, AVL/source, revision, and date. |
| Dual NCE and TFLN visibility question | 2 / 3 / 4 | Use the included schematic overview and native schematic. Confirm U1 NCE-A, U4 NCE-B, U3 TFLN PIC, U50-U53 RF driver chain, and HBM groups. | Manufacturer can trace NCE/TFLN blocks in PDF/SVG/native KiCad schematic and netlist. |
| Real server chassis constraints | 1 / 6 / 8 | Confirm rail, connector, front-panel, airflow, heatsink, mounting-hole, keepout, and service-clearance requirements. | Signed mechanical review confirms 295.0 x 140.0 mm reference envelope and 56.0 mm height note are compatible with the chassis. |
