# Tapeout July_04_DO_OVER_VLSI_FLOW

Date: 2026-07-05

## Purpose

This package maps the manufacturer-provided VLSI design-flow template into a board-specific do-over flow for TFLN_AI_NODE_X2.

It is intended to guide the engineering ECO path from requirement reset through schematic/BOM closure, PCB ECO, verification, DFM/DFA, and production release approval.

## Current engineering state

- Board reference envelope: 295.0 mm x 140.0 mm.
- Height note: 56.0 mm.
- KiCad DRC: 32 open violations.
- Unconnected items: 0.
- Schematic parity: 564 open PCB-vs-schematic items.
- BOM: final procurement BOM is pending ECO/parity closure and signed component-engineering review.

## What changed in this do-over package

- The manufacturer template was converted into a TFLN_AI_NODE_X2-specific flow.
- The engineer fix list is mapped to the flow domains.
- The schematic reference is included so the manufacturer can see U1/U4 dual NCE dies and U3 TFLN PIC.
- The release-output checklist defines what must be regenerated after ECO closure.

## Included files

- `02_do_over_flow_chart/TFLN_AI_NODE_X2_DO_OVER_VLSI_FLOW.pdf`
- `02_do_over_flow_chart/TFLN_AI_NODE_X2_DO_OVER_VLSI_FLOW.png`
- `03_engineering_instructions/TFLN_AI_NODE_X2_DO_OVER_DOMAIN_MATRIX.pdf`
- `03_engineering_instructions/CURRENT_GAPS_TO_FLOW_MAP.pdf`
- `04_release_outputs_required/RELEASE_OUTPUTS_REQUIRED.pdf`
- `05_schematic_reference/SCHEMATIC_VISIBILITY_INDEX.pdf`
- `00_read_me/MANUFACTURER_RESPONSE_DO_OVER.txt`

## Release position

Use this as the ECO and release-closure instruction set. The production package should be issued after DRC closure, schematic parity closure, final BOM signoff, and manufacturer DFM/DFA closure.
