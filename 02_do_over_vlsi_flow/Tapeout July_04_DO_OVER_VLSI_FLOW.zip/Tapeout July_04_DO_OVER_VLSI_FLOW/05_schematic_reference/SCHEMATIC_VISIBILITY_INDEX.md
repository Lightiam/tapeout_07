# Schematic Visibility Index

| Reference | Block | Value | MPN | Where To Look |
| --- | --- | --- | --- | --- |
| U1 | NCE-A die | NCE_Gen3_SpikingBrain | LR-NCE-G3-BGA2500-001 | Clear overview PDF and native KiCad schematic. |
| U4 | NCE-B die | NCE_Gen3_SpikingBrain | LR-NCE-G3-BGA2500-001 | Clear overview PDF and native KiCad schematic. |
| U3 | TFLN photonic IC | TFLN_PIC_4xMZM | TFLN-MZM-400G-C | Clear overview PDF, native schematic, SVG, and schematic BOM. |
| U50-U53 | RF driver chain | HMC8410 | HMC8410LP2FE | Native schematic and schematic BOM. |
| U30-U35 | HBM group for NCE-A | HBM4-16GB | SK_HBM4_16GB_12H | Native schematic and schematic BOM. |
| U40-U45 | HBM group for NCE-B | HBM4-16GB | SK_HBM4_16GB_12H | Native schematic and schematic BOM. |
