# Release Outputs Required

| Required Output | Owner | Release Criteria | Current State |
| --- | --- | --- | --- |
| Signed mechanical specification | Mechanical / system engineering | 295.0 x 140.0 mm envelope, 56.0 mm height note, datum, rails, keepouts, holes, connector exits, heatsink and airflow confirmed. | Reference envelope modeled; signoff pending. |
| Native schematic and schematic PDF/SVG | Electrical engineering | Dual NCE, TFLN PIC, RF/bias, HBM, PCIe/control/power blocks visible and aligned to netlist. | Included in schematic reference; parity closure pending. |
| Final netlists | Electrical engineering | Generated from closed schematic and loaded into PCB with no unexplained differences. | Reference netlists included; final netlist after ECO closure. |
| PCB native project | PCB layout engineering | Updated KiCad project with DRC 0 and no unintended unconnected items. | Current project included in ECO package; DRC/parity still open. |
| Gerbers, drill, drill map, stackup, impedance notes | PCB layout / manufacturer CAM | Regenerated from DRC-clean PCB and approved by DFM. | Review outputs exist; regenerate after ECO closure. |
| Placement and assembly outputs | PCB layout / assembly engineering | XY placement, centroid, assembly drawings, polarity and DNP markings match final BOM. | Release-pending pending BOM and parity closure. |
| Final procurement BOM | Component / procurement engineering | MPN, value, package, quantity, source/AVL, DNP, alternates, revision/date signed. | Current BOM is release-pending; final BOM must follow ECO closure. |
| Validation report | Electrical / PCB verification | DRC 0, unconnected 0, schematic parity closed or signed-waived, ERC reviewed. | DRC 32, unconnected 0, schematic parity 564. |
| DFM/DFA closure report | Manufacturer with engineering review | CAM, panelization, solder mask, silkscreen, drill, stackup, assembly and test risks closed. | Pending ECO-clean outputs. |
| Final release manifest | Release engineering | All final files listed with SHA256, revision, date, and owner approval. | This do-over package includes its own manifest; production manifest comes after closure. |
