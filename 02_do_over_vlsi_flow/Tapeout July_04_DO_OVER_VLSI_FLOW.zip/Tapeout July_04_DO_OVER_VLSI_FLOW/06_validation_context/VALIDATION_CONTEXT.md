# Validation Context

The current release-pending ECO state is:

- Reference envelope: 295.0 mm x 140.0 mm.
- Height note: 56.0 mm.
- KiCad CLI used previously: 10.0.3.
- KiCad DRC: 32 open violations.
- Unconnected items: 0.
- Schematic parity: 564 open PCB-vs-schematic items.

Open DRC groups:

- 7 no-net copper graphics near board edges on EO_Bias_Monitor / Slow_Control.
- 10 top-edge regulator placeholder pad clearances on ULREG / URREG.
- 10 top-row bias/monitor component clearances on CL32 / CR32 / DL32 / DR32 / JL32 / JR32.
- 1 mounting-hole clearance item at MH5.
- 4 silkscreen clipping items at UPWR_L / UPWR_R.

Schematic parity groups:

- 199 net conflicts.
- 199 extra footprints.
- 84 footprint-symbol mismatches.
- 82 footprint/symbol field mismatches, including missing MPN fields.
